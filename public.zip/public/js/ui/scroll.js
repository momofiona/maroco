/**
 * 滚动条
 * @param  {Object} config [description]
 * @return {String}      
 */
"use strict";
define(function(require, exports, module) {
    //如果是webkit return;
    var scroll=function(config){

    }
});
